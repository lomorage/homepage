taskkill /f /im lomod.exe

timeout /t 5 /nobreak

taskkill /f /im lomoagent.exe

timeout /t 5 /nobreak